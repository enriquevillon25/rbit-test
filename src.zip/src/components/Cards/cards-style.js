import { makeStyles } from "tss-react/mui";
import { neutralColors, semanticColors, shadowTokens } from "theme/tokens";

const cardsStyles = makeStyles({ uniqId: "card" })(
  (theme, _params, classes) => ({
    property: {},
    title: {},
    text: {},
    icon: {},
    /* General Card */
    generalCard: {
      position: "relative",
      width: 250,
      height: 400,
      padding: 3,
      "& figure": {
        margin: 0,
        width: "100%",
        height: 170,
        borderRadius: 6,
        overflow: "hidden",
        "& img": {
          width: "100%",
          minHeight: "100%",
        },
      },
      [`& .${classes.property}`]: {
        display: "flex",
        justifyContent: "space-between",
        marginBottom: theme.spacing(2),
        "& strong": {
          fontWeight: theme.typography.fontWeightBold,
        },
      },
    },
    desc: {
      padding: theme.spacing(2),
      "& p": {
        marginBottom: 20,
        overflow: "hidden",
        height: 50,
      },
    },
    button: {
      width: "100%",
      borderWidth: "2px !important",
    },
    rating: {
      "& svg": {
        color: semanticColors.warning,
      },
    },
    /* Category Card */
    figure: {},
    categoryCard: {
      borderRadius: 16,
      marginBottom: theme.spacing(3),
      overflow: "hidden",
      position: "relative",
      border: `1px solid ${neutralColors.borderDark}`,
      background: neutralColors.white,
      borderColor: theme.palette.secondary.light,
      textAlign: "center",
      display: "flex",
      alignItems: "flex-start",
      height: 250,
      [theme.breakpoints.down("sm")]: {
        height: 120,
      },
      [`& .${classes.figure}`]: {
        margin: 0,
        width: "100%",
        display: "block",
        "& img": {
          width: "100%",
          position: "relative",
        },
      },
      [`& .${classes.title}`]: {
        fontWeight: theme.typography.fontWeightBold,
        fontSize: 24,
        whiteSpace: "nowrap",
        position: "relative",
        display: "block",
        textAlign: "center",
        textOverflow: "ellipsis",
        [theme.breakpoints.down("sm")]: {
          overflow: "hidden",
          fontSize: 14,
          textAlign: "center",
          lineHeight: "28px",
        },
      },
      [`& .${classes.property}`]: {
        // transition: 'all 0.3s cubic-bezier(0, .81, 1, .97)',
        position: "absolute",
        height: "25%",
        // width: '100%',
        padding: theme.spacing(2, 6),
        top: 0,
        borderRadius: 16,
        textAlign: "left",
        left: 0,
        color: theme.palette.common.white,
        backdropFilter: "saturate(100%) blur(10px)",
        background: shadowTokens.overlay,
        [theme.breakpoints.down("lg")]: {
          padding: theme.spacing(2),
          bottom: 0,
          [`& .${classes.descCategory}`]: {
            display: "none",
          },
        },
        [theme.breakpoints.down("sm")]: {
          padding: theme.spacing(0.5, 2),
          borderRadius: 8,
        },
      },
      // '&:hover': {
      //   [theme.breakpoints.up('lg')]: {
      //     [`& .${classes.property}`]: {
      //       padding: theme.spacing(4, 6),
      //       [`& .${classes.title}`]: {
      //         '&:after': {
      //           width: '80%',
      //           left: 0
      //         }
      //       },
      //       [theme.breakpoints.up('lg')]: {
      //         height: '80%',
      //         bottom: 0,
      //         opacity: 1,
      //         [`& .${classes.descCategory}`]: {
      //           opacity: 1,
      //           bottom: 0,
      //           height: 70
      //         }
      //       }
      //     },
      //   }
      // }
    },
    descCategory: {
      marginTop: theme.spacing(5),
      fontSize: 22,
      fontWeight: theme.typography.fontWeightRegular,
      whiteSpace: "normal",
      height: 0,
      opacity: 0,
      display: "block",
      overflow: "hidden",
    },
    cardWrap: {
      position: "relative",
    },
    fold: {
    },
    /* Testimonial Card */
    testimonial: {
      height: 260,
      background: theme.palette.background.paper,
      borderRadius: theme.spacing(),
      overflow: "visible",
      border: `3px solid ${theme.palette.divider}`,
      padding: theme.spacing(4, 2),
      [theme.breakpoints.up("sm")]: {
        padding: theme.spacing(8),
      },
      position: "relative",
      [`& .${classes.icon}`]: {
        borderRadius: 20,
        background: theme.palette.primary.main,
        transform: "rotate(45deg)",
        width: 70,
        height: 70,
        top: -30,
        left: 32,
        position: "absolute",
        textAlign: "center",
        lineHeight: "100px",
        [theme.breakpoints.down("sm")]: {
          display: "none",
        },
        "& svg": {
          transform: "translateY(-15px) rotate(-45deg)",
          width: 70,
          height: 70,
          verticalAlign: "middle",
          fill: theme.palette.common.white,
        },
      },
      "& h6": {
        fontWeight: theme.typography.fontWeightBold,
      },
      [`& .${classes.text}`]: {
        marginBottom: theme.spacing(4),
        overflow: "hidden",
        display: "-webkit-box",
        WebkitLineClamp: 3,
        WebkitBoxOrient: "vertical",
        height: theme.spacing(9),
      },
    },
    caption: {
      color: theme.palette.text.secondary,
    },
    /* Blog Card */
    blogCard: {
      display: "flex",
      marginBottom: theme.spacing(6),
      alignItems: "center",
      position: "relative",
      [theme.breakpoints.down("sm")]: {
        marginBottom: theme.spacing(3),
      },
      "&:before": {
        borderRadius: 15,
        content: '""',
        width: 100,
        height: 100,
        transform: "rotate(45deg)",
        background: theme.palette.secondary.main,
        opacity: 0.1,
        position: "absolute",
        top: -10,
        left: -25,
      },
      [`& .${classes.text}`]: {
        "& a": {
          padding: 0,
          position: "relative",
          textTransform: "none",
          zIndex: 1,
          whiteSpace: "inherit",
          color: theme.palette.text.primary,
          lineHeight: "36px",
          "&:hover": {
            background: "none",
          },
        },
        "& > a": {
          fontWeight: theme.typography.fontWeightRegular,
          color: theme.palette.text.secondary,
        },
        "& h4": {
          lineHeight: "normal",
          "&:before": {
            borderRadius: 10,
            content: '""',
            width: 50,
            height: 50,
            transform: "rotate(45deg)",
            background:
              theme.palette.mode === "light"
                ? theme.palette.secondary.light
                : theme.palette.secondary.dark,
            position: "absolute",
            top: -6,
            left: -25,
          },
          "& a": {
            display: "block",
            fontSize: 24,
            fontWeight: theme.typography.fontWeightMedium,
            transition: "all 0.3s ease",
            height: 80,
            [theme.breakpoints.down("sm")]: {
              fontSize: 16,
              lineHeight: "22px",
            },
            "&:hover": {
              color: theme.palette.primary.main,
            },
          },
        },
      },
    },
    date: {
      textAlign: "center",
      marginLeft: theme.spacing(3),
      color: theme.palette.text.disabled,
      "& > *": {
        display: "block",
        fontWeight: theme.typography.fontWeightRegular,
      },
      "& h3": {
        fontSize: 28,
        textTransform: "uppercase",
        [theme.breakpoints.down("sm")]: {
          fontSize: 20,
        },
      },
      "& h2": {
        fontSize: 46,
        [theme.breakpoints.down("sm")]: {
          fontSize: 32,
        },
      },
      "& h4": {
        fontSize: 22,
        [theme.breakpoints.down("sm")]: {
          fontSize: 16,
        },
      },
    },
  })
);

// TODO jss-to-tss-react codemod: usages of this hook outside of this file will not be converted.
export default cardsStyles;
